import java.util.Scanner;
public class TablePrint{
	
	static Scanner sc;
		
	private void execute(){
		long result;
		
		System.out.println("Enter Number To Print Table");
		while (!sc.hasNextInt()) {
        		System.out.println("It's Not a Number!!! Enter valid Number To Continue..");
        		System.out.println("Number Should be less then 2000000001");
        		sc.next();
    		}	
    		
		final int n=sc.nextInt();
		
		for(int i=1;i<=10;i++){
			result = n*i;
			System.out.println(n+" * "+i+" = "+result);
		}
		
		System.out.println("Enter Your Choice");
		selectChoice();
	}
		
	private void selectChoice(){
		System.out.println("for continue press : c/C");
		System.out.println("for terminate press : t/T");
	
		final char ch = sc.next().charAt(0);
		checkCondition(ch);
	}
		
	 private void checkCondition(char ch){
	
	switch(ch){
	      
	      	case 'c':
		case 'C':
			execute();
		case 't':	
		case 'T':
			System.out.println("Your process is End");
			break;
		default :
			System.out.println("Wrong Choice.... Chose from given.");
              		selectChoice();
		}
	}
	public static void main(String[] args){
		sc = new Scanner(System.in);
		
		TablePrint t = new TablePrint();
		t.execute();
	}
}


 
