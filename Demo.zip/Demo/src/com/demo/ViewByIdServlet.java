package com.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ViewByIdServlet")
public class ViewByIdServlet extends HttpServlet {
    int id;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        id = Integer.parseInt(request.getParameter("id"));
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

      Employee employee = new Employee(id);

        Employee list = CrudOperations.getEmployeeById(id);
//        List<Employee> list = (List<Employee>) CrudOperations.getEmployeeById(id);
        request.setAttribute("data", list);

        request.getRequestDispatcher("/Read.jsp").forward(request, response);

    }
}
