package com.demo;

import java.util.*;

public class CrudOperations {

//    protected static int keyNo=0;
    protected static String name,age,salary,city,mob,email,gen;
    protected static Map<Integer, Employee> map = new HashMap<Integer, Employee>();


//    public int increaseId(){
////        int keyNo=0;
//        return keyNo+=1;
//    }
//Map<int ,Person> personmap=new HashMap();
//personmap.put(person.setId(IncrementIdByOne(),Person));


    public static Employee add(Employee employee) {
//    keyNo+=1;

//        map.put(employee.setId(employee.IncrementIdByOne(),Employee));
        map.put(employee.setId(),employee);
        System.out.println(employee.getId());

        System.out.println("Record Added Successfully"+employee.toString());
        return employee;
    }

    public static List<Employee> view() {
        Collection<Employee> collection = map.values();
        List<Employee> list = new ArrayList<Employee>();
        list.addAll(collection);

        System.out.println(list);
        return list;
    }

    public static Employee getEmployeeById(int id) {
        return map.get(id);
    }

    public static Employee updateEmployee(Employee employee) {
        try {
            map.put(employee.getId(), employee);
        }catch (Exception e){}
        System.out.println("Record Update Successfully");
        return employee;
    }

    public static void deleteEmployee(int id) {
        try {
            map.remove(id);
        }catch (Exception e){System.out.println("Wrong Input");deleteEmployee(id);}
        System.out.println("Record Deleted Successfully");
    }


}
