import java.util.Scanner;
public class Table{
	public static void main(String[] args){
	
		System.out.println("Enter Number to Print Table");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int r;	
		for(int i=1;i<=10;i++){
			r=n*i;
			System.out.println(+n+" * "+i+" = "+r);
		}
	}
}
