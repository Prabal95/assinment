import java.util.Scanner;
public class ReverseInteger{
	public static void main(String[] args){
	
		System.out.println("Enter Number to reverse it : ");
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		int rmnd,rvrs=0;
		
		while(n!=0){
			rmnd = n%10;
			rvrs = (rvrs*10)+rmnd;
			n=n/10;
		}
		System.out.println(" Reverse Integer is : "+rvrs);
	}
}
