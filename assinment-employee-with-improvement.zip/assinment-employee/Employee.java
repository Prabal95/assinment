import java.util.*;
import java.io.*;

public class Employee{

	private static int choice,keyNo=0,ch=0;
	private static String name,city,mob,email,gen;
	private static int age,salary,id=0;
	private static BufferedReader br;
	private static Map<Integer, List<String>> map;
	private static List<String> list;

	public Employee(){
		this.name = name;
		this.age = age;
		this.salary = salary;
		this.city = city;
		this.mob = mob;
		this.email = email;
		this.gen = gen;
	}

	
	private static void add(){
		
		list = new ArrayList<String>();
        	
		try{
		System.out.println("Enter Employee Name");
			name = br.readLine();
				if (!name.matches("[a-zA-Z_ ]+")){
    				System.out.println("Invalid name (Enter only alphabate)");
    				add();
				}
			list.add(name);
			
		System.out.println("Enter Employee Age (*Between Or Equal 18 to 60)");
			age = Integer.parseInt(br.readLine());
				if(age<18 || age>60){
					System.out.println("Your Age is Not Right to be a Employee");
					add();
				}
			list.add(String.valueOf(age));
			
		System.out.println("Enter Employee Salary");
			salary = Integer.parseInt(br.readLine());
				if(salary<5000){
					System.out.println("Salary Not Less Then 5000....");
					add();
				}
			list.add(String.valueOf(salary));
			
		System.out.println("Enter Employee City");
			city = br.readLine();
				if (!city.matches("[a-zA-Z_ ]+")){
    				System.out.println("Invalid city (Enter only Alphabate)");
    				add();
				}
			list.add(city);
			
		System.out.println("Enter Employee Mobile");
			mob = br.readLine();
				if (!mob.matches("(0/91)?[6-9][0-9]{9}")) {
    				System.out.println("Invalid number (Number Should be start with between 6to9) (And Digit of Mob. Number should be 10)");add();}
			list.add(mob);
			
		System.out.println("Enter Employee Email");
			email = br.readLine();
				if(!email.matches("^(.+)@(.+)$")){
					System.out.println("Invalid Email");
					add();
				}
			list.add(email);
			
		System.out.println("Enter Employee Gender (m/M Or f/F)");
			gen = br.readLine();
				if(!gen.matches("[mMFf]")){System.out.println("select from given");
					add();}
			list.add(gen);
		}catch(Exception e){System.out.println(e);add();}
		
		map.put(keyNo, list);
		
		System.out.println("Record Added Successfully");
		home();
	}

	private static void viewCondition(){
		System.out.println("1 - View All");
		System.out.println("2 - View By Id");
		System.out.println("Select And Press Key for Your Choice :");
		
		try{
			choice = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);viewCondition();}

		try{
			switch(choice)
			{
				case 1:{
					view();
					break;
					}
				case 2:{
					viewById();
					break;}
				default:
					System.out.println("Wrong Selection / Press Key From Given Ch");
					viewCondition();	break;
			}
		}catch(Exception e){
			System.out.println(e);viewCondition();
		}
		
	}
	private static void viewById(){
		System.out.println("Enter Employee Id");
		try{
			id = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);viewById();}
		
		System.out.println(" ID. Emp. Name | Age | Salary | City | Mobile | Email | gen ");
		for(Map.Entry<Integer,List<String>> entry : map.entrySet()){
			int key = entry.getKey();
			List<String> values = entry.getValue();
			
			if(id == key){
			System.out.println("  "+key+"    "+values.toString()+ "   ");
			}else{System.out.println("Id is Not Valid");}	
		}
	home();
	}
	
	private static void view(){
		
 	    System.out.println(" ID. Emp. Name | Age | Salary | City | Mobile | Email | gen ");
	 try{
	    for (Map.Entry<Integer, List<String>> entry : map.entrySet()) {
            	int key = entry.getKey();
		
               	List<String> values = entry.getValue();
		System.out.println("  "+key+"    "+values.toString()+ "   ");	
            }
	    }catch(Exception e){System.out.println(e);view();}
	home();
	}

	private static void update(){
	
	System.out.println(" ID. Emp. Name | Age | Salary | City | Mobile | Email | gen ");
	for (Map.Entry<Integer, List<String>> entry : map.entrySet()) {
            	int key = entry.getKey();
            	List<String> values = entry.getValue();
	    	System.out.println("  "+key+"   "+values.toString()+ " ");
	}
		System.out.println("Enter Your Choice to Update Record");
		try{
			ch = Integer.parseInt(br.readLine());
			
		}catch(Exception ex){System.out.println(ex);update();}
		
	
		System.out.println("Which value want to change ?");
		System.out.println("1 - Name");
		System.out.println("2 - Age");
		System.out.println("3 - Salary");
		System.out.println("4 - City");
		System.out.println("5 - Mobile");
		System.out.println("6 - Email");
		System.out.println("7 - Gender");
		System.out.println("Select And Press Key for Your Choice :");
		try{
			choice = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);update();}

		//System.out.println("You Are Update the value of key : "+ch);
		list = map.get(ch);
		System.out.println(list);
		try{
			switch(choice)
			{
				case 1:{
					System.out.println("Enter Employee Name");
					name = br.readLine();
					list.set(0,name);
					break;
					}
				case 2:{
					System.out.println("Enter Employee Age");
					age = Integer.parseInt(br.readLine());
					list.set(1,""+age);
					break;}
				case 3:{
					System.out.println("Enter Employee Salary");
					salary = Integer.parseInt(br.readLine());
					list.set(2,""+salary);
					break;}
				case 4:{
					System.out.println("Enter Employee City");
					city = br.readLine();
					list.set(3,city);
					break;}
				case 5:{
					System.out.println("Enter Employee Mobile");
					mob = br.readLine();
					list.set(4,mob);
					break;}
				case 6:{
					System.out.println("Enter Employee Email");
					email = br.readLine();
					list.set(5,email);
					break;}
				case 7:{
					System.out.println("Enter Employee Gender");
					gen = br.readLine();
					list.set(6,gen);
					break;}
				default:
					System.out.println("Wrong Selection / Select From Given");
					getChoice();	
			}
		    
		}catch(Exception e){
			System.out.println(e);update();
		}
		
		map.replace(ch, list);
		System.out.println("Record Update SuccessFully"); 
	home();	
	}

	private static void delete(){
	int key;
	System.out.println(" ID. Emp. Name | Age | Salary | City | Mobile | Email | gen ");
	for (Map.Entry<Integer, List<String>> entry : map.entrySet()) {
            	key = entry.getKey();
            	List<String> values = entry.getValue();
	    	System.out.println("  "+key+"   "+values.toString()+ " ");
	}
		System.out.println("Enter Your Choice to Delete Record");
		try{
			ch = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);delete();}
		
		map.remove(ch);
		//System.out.println("map is: "+ch); 
		
		System.out.println("Record Deleted Successfully ");
		
		 try{
	    
		for (Map.Entry<Integer, List<String>> entry : map.entrySet()) {
            	key = entry.getKey(); 
  		for(int i=1;i<=map.size();i++){
			if(key>ch){
			     int tmp = key;
			     key = ch;
			     ch = tmp;
			     	
				map.put(key, map.remove(keyNo));
			}
			
		}
		List<String> values = entry.getValue();
		
      			
            }
	    }catch(Exception e){System.out.println(e);delete();}
		keyNo=ch;
	home();	
	}
	
	private static void home(){
		
		System.out.println("1 - Add More Record");
		System.out.println("2 - Home");
		System.out.println("0 - Exit");
		System.out.println("Select And Press Key for Your Choice :");
		try{
			choice = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);home();}
		

		try{
			switch(choice)
			{
				case 1:{
					keyNo+=1;
					add();
					break;
					}
				case 2:
					getChoice();
					break;
				case 0:
					exit();
					break;
				default:
					System.out.println("Wrong election / Select From Given");
					home();break;	
			}
		    
		}catch(Exception e){
			System.out.println(e);home();
		}
	}

	private static void exit(){
		System.out.println("Bye Bye !! Have A Good Day....");
		System.exit(0);
	}
	
	private static void getChoice(){
		System.out.println(" ----------Welcome---------- ");
		
		System.out.println("1 - Add");
		System.out.println("2 - View");
		System.out.println("3 - Update");
		System.out.println("4 - Delete");
		System.out.println("0 - Exit");
		System.out.println("Select And Press Key for Your Choice :");
		try{
			choice = Integer.parseInt(br.readLine());
		}catch(Exception ex){System.out.println(ex);getChoice();}
		

		try{
			switch(choice)
			{
		    
				case 1:{
					keyNo+=1;
					add();
					break;
					}
				case 2:
					{
					viewCondition();
					break;
					}
				case 3:
					update();
					break;
				case 4:
					delete();
			
					break;
				case 0:
					exit();
					break;
		    
				default:
					System.out.println("Wrong Selection / Press Key From Given");
					getChoice();break;	
			}
		    
		}catch(Exception e){
			System.out.println(e);getChoice();
		}
	}

	public static void main(String[] args){
	
		br = new BufferedReader(new InputStreamReader(System.in)); 
	
		map = new HashMap<Integer, List<String>>();
		list = new ArrayList<String>();
		
		getChoice();
	
	}
}
