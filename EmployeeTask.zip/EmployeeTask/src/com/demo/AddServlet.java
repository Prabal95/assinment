package com.demo;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.Map;


public class AddServlet extends HttpServlet {

    protected String name,age,salary,city,mob,email,gen;
    protected Map<Integer, String> map = new HashMap<Integer, String>();


    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

        Employee employee = new Employee(name,age,salary,city,mob,email,gen);

        CrudOperations.add(employee);

        request.getRequestDispatcher("").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        name = request.getParameter("name");
        age = request.getParameter("age");
        salary = request.getParameter("salary");
        city = request.getParameter("city");
        mob = request.getParameter("mob");
        email = request.getParameter("email");
        gen = request.getParameter("gen");

    }
}
